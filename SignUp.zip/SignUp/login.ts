
let vv:any;
let vvv:any;
function sumnm()
{
vv=  (<HTMLInputElement>document.getElementById("username")).value;  
vvv=  (<HTMLInputElement>document.getElementById("password")).value;  
    console.log("Username given by user :- "+vv);
    console.log("password given by user :- "+vvv);
}
let Data =[];
    function loadDoc() {
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      
        Data = JSON.parse(this.responseText);
       
            for(let i=0;i<Data.length;i++)
            {
               
                if(Data[i].email_id== vv && Data[i].password==vvv)
                {
                    console.log("username genrated by JSON file :- "+Data[i].email_id)
                    console.log("password genrated by JSON file :- "+Data[i].password)
              console.log("Welcome to css corp");
document.getElementById("one").innerHTML ="Welcome to CSS CORP 'You are scuessfully loged in..!'" ;
             console.log("Title is :- "+Data[i].email_id)
             document.getElementById("two").innerHTML ="First Name : "+Data[i].First_Name+"<br>"+"Last name: "+Data[i].Last_Name+"<br>"+"User Name: "+Data[i].email_id+"<br>"+"Pincode: "+Data[i].Pincode+"<br>"+"Date of Birth: "+Data[i].Date_of_Birth+"<br>"+"Country: "+Data[i].countySel+"<br>"+"State: "+Data[i].stateSel+"<br>"+"City: "+Data[i].districtSel ;
             document.getElementById("show_data").style.display="block";
             break;
                }
                else if(i==Data.length-1)
                {
                    console.log("Username and Password Does not match");
                    document.getElementById("three").innerHTML ="Username and Password Does not match....!" ;
                }
             
            }
               
                

       
      // document.getElementById("demo").innerHTML = this.responseText;
    }
  };
  // xhttp.open("GET", "https://jsonplaceholder.typicode.com/todos", true);

  xhttp.open("GET", "http://localhost:3000/books", true);
  xhttp.send();
}

function showData()
{
  document.getElementById("two").style.display="block";
}
