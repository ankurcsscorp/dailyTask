
        function sub() {
             
            let a = (<HTMLInputElement>document.getElementById("inp1")).value; 
            let b = (<HTMLInputElement>document.getElementById("inp2")).value; 
            let c = (<HTMLInputElement>document.getElementById("inp3")).value; 
            let d = (<HTMLInputElement>document.getElementById("inp4")).value; 
            let e = (<HTMLInputElement>document.getElementById("inp5")).value;
            let f =(<HTMLInputElement>document.getElementById("countySel")).value; 
            let g =(<HTMLInputElement>document.getElementById("stateSel")).value; 
            let h =(<HTMLInputElement>document.getElementById("districtSel")).value;
          
            console.log(a);




            if (a == "" || b == "" || c == "" || d == "" || e == "" || f=="" || g=="" || h=="") {
                alert('Please fill all the mandatory fields');
            }
            else if (d <= 8 || e <= 8) {
                alert("please give password length of 8 or above");
            }
            else if(d.search(/[0-9]/)<0){
                alert("password should contain numbers");

            }
            else if(d.search(/[A-Z]/)<0){
                alert("password should contain upper case ");

            }
            else if(d.search(/[a-z]/)<0){
                alert("password should contain lower case ");

            }
            else if(d.search(/[!@#$%^&*]/)<0){
                alert("password should contain special charecter ");

            }
             
            else if (d != e) {
                alert("password does not match");
            }

            else {
                document.getElementById('container').innerHTML = 'Hi.. welcome, you are sucessfully logged in !';
            }
        }

        let stateObject = {
            "India": {
                "Delhi": ["new Delhi", "North Delhi"],
                "Kerala": ["Thiruvananthapuram", "Palakkad"],
                "Goa": ["North Goa", "South Goa"],
            },
            "Australia": {
                "South Australia": ["Dunstan", "Mitchell"],
                "Victoria": ["Altona", "Euroa"]
            }, "Canada": {
                "Alberta": ["Acadia", "Bighorn"],
                "Columbia": ["Washington", ""]
            },
        }
        window.onload = function () {
            var countySel = document.getElementById("countySel"),
                stateSel = document.getElementById("stateSel"),
                districtSel = document.getElementById("districtSel");
            for (var country in stateObject) {
                countySel.options[countySel.options.length] = new Option(country, country);
            }
            countySel.onchange = function () {
                stateSel.length = 1; // remove all options bar first
                districtSel.length = 1; // remove all options bar first
                if (this.selectedIndex < 1) return; // done 
                for (let state in stateObject[this.value]) {
                    stateSel.options[stateSel.options.length] = new Option(state, state);
                }
            }
            countySel.onchange(); // reset in case page is reloaded
            stateSel.onchange = function () {
                districtSel.length = 1; // remove all options bar first
                if (this.selectedIndex < 1) return; // done 
                var district = stateObject[countySel.value][this.value];
                for (let i = 0; i < district.length; i++) {
                    districtSel.options[districtSel.options.length] = new Option(district[i], district[i]);
                }
            }
        }

        let obj, dbParam, xmlhttp, myObj, x, txt = "";

        obj = { table: "customers", limit: 20 };

        dbParam = JSON.stringify(obj);

        xmlhttp = new XMLHttpRequest();

        xmlhttp.onreadystatechange = function() {

          if (this.readyState == 4 && this.status == 200) {

            myObj = JSON.parse(this.responseText);

            txt += "<table border='1'>"

            for (x in myObj) {
              txt += "<tr><td>" + myObj[x].name + "</td></tr>";
            }

            txt += "</table>"    
            document.getElementById("demo").innerHTML = txt;
          }
        };
        xmlhttp.open("POST", "sample.json", true);
        xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xmlhttp.send("x=" + dbParam);