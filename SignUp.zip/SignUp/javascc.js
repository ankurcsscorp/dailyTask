// function sub() {
//     obj = { 
//             name:'manju',
//             company: 'csscorp'
//     };
function funny()
{
var input2 = document.querySelectorAll('select'); 
var input1= document.querySelector('textarea');
var inputs = document.querySelectorAll('input');    
var myObject = {};

for (var i = 0; i < inputs.length; i++) {
myObject[inputs[i].id] = inputs[i].value;
}



for (var j = 0; j < input2.length; j++) {
    myObject[input2[j].id] = input2[j].value;
    }
    myObject[input1.id]=input1.value;
console.log(myObject) // {firstName: "", lastName: "", email: "", number: ""}

dbParam = JSON.stringify(myObject);
xmlhttp = new XMLHttpRequest();
xmlhttp.onreadystatechange = function () {
    if (this.readyState == 4 && this.status == 200) {
       // myObj = JSON.parse(this.responseText);
        console.log(this.responseText);
        //document.getElementById("demo").innerHTML = "jkasdhajjk  jkasdk";
    }
};
xmlhttp.open("POST", "http://localhost:3000/books",true );
xmlhttp.setRequestHeader("Content-type","application/json");
xmlhttp.send(dbParam);
}
function sub()
{
    var a = document.getElementById("First_Name").value;
    var b = document.getElementById("Last_Name").value;
    var c = document.getElementById("email_id").value;
    var d = document.getElementById("password").value;
    var e = document.getElementById("Re_password").value;
    var f = document.getElementById("countySel").value;
    var g = document.getElementById("stateSel").value;
    var h = document.getElementById("districtSel").value;
    let atposition=c.indexOf('@');
let dotposition=c.indexOf('.'); 
    console.log(a);
    if (a == "" || b == "" || c == "" || d == "" || e == "" || f == "" || g == "" || h == "") {
        alert('Please fill all the mandatory fields');
    }
    else if (d <= 8 || e <= 8) {
        alert("please give password length of 8 or above");
    }
    else if (atposition<1 || dotposition<atposition+2 || dotposition+2>=eAddress.length) {
        alert("Please enter the valid email id");
    }
    else if (d.search(/[0-9]/) < 0) {
        alert("password should contain numbers");
    }
    else if (d.search(/[A-Z]/) < 0) {
        alert("password should contain upper case ");
    }
    else if (d.search(/[a-z]/) < 0) {
        alert("password should contain lower case ");
    }
    else if (d.search(/[!@#$%^&*]/) < 0) {
        alert("password should contain special charecter ");
    }
    else if (d != e) {
        alert("password does not match");
    }
    else {
        funny();
        document.getElementById('container').innerHTML = 'Hi.. welcome, you are sucessfully logged in !';
        
    }
}
var stateObject = {
    "India": {
        "Delhi": ["new Delhi", "North Delhi"],
        "Kerala": ["Thiruvananthapuram", "Palakkad"],
        "Goa": ["North Goa", "South Goa"], 
        "Karnataka": ["Bangalore", "Simaoga","Masure"]
    },
    "Australia": {
        "South Australia": ["Dunstan", "Mitchell"],
        "Victoria": ["Altona", "Euroa"]
    }, "Canada": {
        "Alberta": ["Acadia", "Bighorn"],
        "Columbia": ["Washington", ""]
    }
};
window.onload = function () {
    var countySel = document.getElementById("countySel"),
    stateSel = document.getElementById("stateSel"),
    districtSel = document.getElementById("districtSel");
    for (var country in stateObject) {
        countySel.options[countySel.options.length] = new Option(country, country);
    }
    countySel.onchange = function () {
        stateSel.length = 1; // remove all options bar first
        districtSel.length = 1; // remove all options bar first
        if (this.selectedIndex < 1)
            return; // done 
        for (var state in stateObject[this.value]) {
            stateSel.options[stateSel.options.length] = new Option(state, state);
        }
    };
    countySel.onchange(); // reset in case page is reloaded
    stateSel.onchange = function () {
        districtSel.length = 1; // remove all options bar first
        if (this.selectedIndex < 1)
            return; // done 
        var district = stateObject[countySel.value][this.value];
        for (var i = 0; i < district.length; i++) {
            districtSel.options[districtSel.options.length] = new Option(district[i], district[i]);
        }
    };
};
// var obj, dbParam, xmlhttp, myObj, x, txt = "";

