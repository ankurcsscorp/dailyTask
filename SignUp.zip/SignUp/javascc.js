function sub() {
    var a = document.getElementById("inp1").value;
    var b = document.getElementById("inp2").value;
    var c = document.getElementById("inp3").value;
    var d = document.getElementById("inp4").value;
    var e = document.getElementById("inp5").value;
    var f = document.getElementById("countySel").value;
    var g = document.getElementById("stateSel").value;
    var h = document.getElementById("districtSel").value;
    console.log(a);
    if (a == "" || b == "" || c == "" || d == "" || e == "" || f == "" || g == "" || h == "") {
        alert('Please fill all the mandatory fields');
    }
    else if (d <= 8 || e <= 8) {
        alert("please give password length of 8 or above");
    }
    else if (d.search(/[0-9]/) < 0) {
        alert("password should contain numbers");
    }
    else if (d.search(/[A-Z]/) < 0) {
        alert("password should contain upper case ");
    }
    else if (d.search(/[a-z]/) < 0) {
        alert("password should contain lower case ");
    }
    else if (d.search(/[!@#$%^&*]/) < 0) {
        alert("password should contain special charecter ");
    }
    else if (d != e) {
        alert("password does not match");
    }
    else {
        document.getElementById('container').innerHTML = 'Hi.. welcome, you are sucessfully logged in !';
    }
}
var stateObject = {
    "India": {
        "Delhi": ["new Delhi", "North Delhi"],
        "Kerala": ["Thiruvananthapuram", "Palakkad"],
        "Goa": ["North Goa", "South Goa"], 
        "Karnataka": ["Bangalore", "Simaoga","Masure"]
    },
    "Australia": {
        "South Australia": ["Dunstan", "Mitchell"],
        "Victoria": ["Altona", "Euroa"]
    }, "Canada": {
        "Alberta": ["Acadia", "Bighorn"],
        "Columbia": ["Washington", ""]
    }
};
window.onload = function () {
    var countySel = document.getElementById("countySel"), stateSel = document.getElementById("stateSel"), districtSel = document.getElementById("districtSel");
    for (var country in stateObject) {
        countySel.options[countySel.options.length] = new Option(country, country);
    }
    countySel.onchange = function () {
        stateSel.length = 1; // remove all options bar first
        districtSel.length = 1; // remove all options bar first
        if (this.selectedIndex < 1)
            return; // done 
        for (var state in stateObject[this.value]) {
            stateSel.options[stateSel.options.length] = new Option(state, state);
        }
    };
    countySel.onchange(); // reset in case page is reloaded
    stateSel.onchange = function () {
        districtSel.length = 1; // remove all options bar first
        if (this.selectedIndex < 1)
            return; // done 
        var district = stateObject[countySel.value][this.value];
        for (var i = 0; i < district.length; i++) {
            districtSel.options[districtSel.options.length] = new Option(district[i], district[i]);
        }
    };
};
var obj, dbParam, xmlhttp, myObj, x, txt = "";
obj = { table: "customers", limit: 20 };
dbParam = JSON.stringify(obj);
xmlhttp = new XMLHttpRequest();
xmlhttp.onreadystatechange = function () {
    if (this.readyState == 4 && this.status == 200) {
        myObj = JSON.parse(this.responseText);
        document.getElementById("demo").innerHTML = "jkasdhajjk  jkasdk";
    }
};
xmlhttp.open("POST", "https://docs.google.com/document/d/1hw_4eqy08Bs6rSZ36HEivWUca9vxUie2jsB6irr4no8/edit?usp=sharing", true);
xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
xmlhttp.send();
