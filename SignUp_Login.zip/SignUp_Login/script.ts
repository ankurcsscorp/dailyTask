let vv:any;
let vvv:any;
function sumnm()
{
vv=  (<HTMLInputElement>document.getElementById("username")).value;  
vvv=  (<HTMLInputElement>document.getElementById("password")).value;  
    console.log("Username given by user :- "+vv);
    console.log("password given by user :- "+vvv);
}
Data =[];
    function loadDoc() {
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      
        Data = JSON.parse(this.responseText);
       
            for(let i=0;i<200;i++)
            {
               
                if(Data[i].userId== vv && Data[i].id==vvv)
                {
                    console.log("username genrated by JSON file :- "+Data[i].userId)
                    console.log("password genrated by JSON file :- "+Data[i].id)
console.log("Welcome to css corp");
document.getElementById("one").innerHTML ="Welcome to CSS CORP 'You are scuessfully loged in..!'" ;
             console.log("Title is :- "+Data[i].title)
             document.getElementById("two").innerHTML ="The title is :- "+Data[i].title ;
             break;
                }
                else if(i==199)
                {
                    console.log("Username and Password Does not match");
                    document.getElementById("three").innerHTML ="Username and Password Does not match....!" ;
                }
             
            }
               
                

       
      document.getElementById("demo").innerHTML = this.responseText;
    }
  };
  xhttp.open("GET", "https://jsonplaceholder.typicode.com/todos", true);
  xhttp.send();
}

