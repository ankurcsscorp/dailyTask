

 export class Contact{

//     constructor(public username:any,public password:any){
   
//     }
// }
// export default Contact;
// let cc = new Contact((<HTMLInputElement>document.getElementById("username")).value , (<HTMLInputElement>document.getElementById("password")).value);
// console.log(cc.username);
// console.log(cc.password);

my_data: any;
public getResponseData() : Promise<any> {
    if(typeof(this.my_data) === "undefined") {
          return this.http.get('assets/data.json')
          .toPromise().then(res => {

                                this.my_data = res.json().response;
                                return this.my_data;
              }).catch(this.handleError);
    } else {
        return Promise.resolve(this.my_data);
    }


}

