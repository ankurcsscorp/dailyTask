function validate() {
  var user = document.getElementById("username").value;
 var pass = document.getElementById("password").value;
    console.log(user);
   
}
//    json


function myFunction(){
           
    document.getElementById("soln").style.background = "black";
    document.getElementById("soln").style.color = "#fff";

    if (ans1.style.display === "none") {
        ans1.style.display = "block";
} else {
ans1.style.display = "none";
}
   
}

function myFunction2(){
    if (ans2.style.display === "none") {
        ans2.style.display = "block";
} else {
ans2.style.display = "none";
}

    document.getElementById("soln2").style.background = "black";
    document.getElementById("soln2").style.color = "#fff";
}

function myFunction3(){
    if (ans3.style.display === "none") {
        ans3.style.display = "block";
} else {
ans3.style.display = "none";
}
    document.getElementById("soln3").style.background = "black";
    document.getElementById("soln3").style.color = "#fff";
}




function display(data) {    
    $.each(data, function(key,value) {
        
     $('#quiz').append('<li>'+'<span class="ui-li-aside">'+ value.quiz.sport.q1.user +'</span></li>');
        $('#quiz').append(''+'<span class="ui-li-aside">'+ value.quiz.sport.q1.password +'</span><br>');
       
        $('#quiz').append(''+'<span class="ui-li-aside answer"><button id="soln" onclick="myFunction()">click here for user detail</button></span><br><br>');
        $('#quiz').append(''+'<span class="ui-li-aside" style="display:none;" id="ans1">'+ value.quiz.sport.q1.detail +'</span><br><br>');
        

    //    if(user==  value.quiz.sport.q1.user )
    //    {
    //        console.log(user);
    //    }
   

    });
}
$(document).ready(function() {
    var data = [
        {
            "quiz": {
                "sport": {
                    "q1": {
                        "user": "ankur123",
                        "password": 
                            "welcome@123",
                        
                        "detail": "full user detail whatever they gave while signup time."
                    }
                }
               
            }
        }          
    ];
display(data);
});