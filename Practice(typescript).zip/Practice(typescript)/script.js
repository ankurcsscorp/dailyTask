function first() {
    var str = document.getElementById("first").value;
    var output = str.split('');
    var count = 0;
    for (var i = 0; i < output.length; i++) {
        if (i == 0 && output[i] != ' ' || output[i] != ' ' && output[i - 1] != ' ' || output[i] != ' ' && output[i - 1] == ' ') {
            count++;
        }
    }
    document.getElementById("demo1").innerHTML = "The total number of charecter in the sentance is : " + count;
    console.log(count);
}
// second
function second() {
    var str = document.getElementById("first").value;
    var output = str.split('');
    var count = 0;
    for (var i = 0; i < output.length; i++) {
        if (i == 0 && output[i] != ' ' || output[i] != ' ' && output[i - 1] == ' ') {
            count++;
        }
    }
    document.getElementById("demo2").innerHTML = "The total number of word in the sentance is : " + count;
    console.log(count);
}
// arrayFunction
var fruits = [];
document.getElementById("result").innerHTML = fruits;
function myFunction() {
    var x = document.getElementById("input").value;
    fruits.push(x);
    document.getElementById("input").value = "";
    document.getElementById("result").innerHTML = fruits;
}
