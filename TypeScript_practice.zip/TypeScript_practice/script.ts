function summ()
{
    let variable= document.getElementById("aaa").value;
    console.log(variable);
}
