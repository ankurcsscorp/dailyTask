function summ() {
    var variable = document.getElementById("aaa").value;
    console.log(variable);
}
