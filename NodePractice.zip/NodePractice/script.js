var nodemailer = require('nodemailer');

var transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'kankur.java@gmail.com',
    pass: 'Ankur@12345'
  }
});

var x = Math.floor(Math.random() * 10000);

var mailOptions = {
  from: 'kankur.java@gmail.com',
  to: 'ankurs632@gmail.com',
  subject: 'Sending Email using Node.js',
  text: 'That was easy way !' + x
};

transporter.sendMail(mailOptions, function(error, info){
  if (error) {
    console.log(error);
  } else {
    console.log('Email sent: ' + info.response);
  }
});