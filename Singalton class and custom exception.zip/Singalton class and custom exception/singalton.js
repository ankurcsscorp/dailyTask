var SingaltonClass = /** @class */ (function () {
    function SingaltonClass() {
    }
    SingaltonClass.getInstance = function () {
        if (this.instance == null) {
            SingaltonClass.instance = new SingaltonClass();
        }
        return this.instance;
    };
    SingaltonClass.instance = null;
    return SingaltonClass;
}());
function clientCode() {
    var s1 = SingaltonClass.getInstance();
    var s2 = SingaltonClass.getInstance();
    if (s1 === s2) {
        document.getElementById("demo").innerText = "Singleton works, both variables contain the same instance.";
        console.log('Singleton works, both variables contain the same instance.');
    }
    else {
        document.getElementById("demo").innerText = "Singleton failed, variables contain different instances.";
        console.log('Singleton failed, variables contain different instances.');
    }
}
