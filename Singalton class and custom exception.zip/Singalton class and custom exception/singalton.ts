class SingaltonClass
{
    private static  instance:SingaltonClass= null;
    private constructor(){   
    }

    public static  getInstance():SingaltonClass
    {
        if(this.instance==null)
        {
            SingaltonClass.instance= new SingaltonClass();
        }
       return this.instance;
    }
}
function clientCode() {
    const s1 = SingaltonClass.getInstance();
    const s2 = SingaltonClass.getInstance();

    if (s1 === s2) {
        document.getElementById("demo").innerText="Singleton works, both variables contain the same instance.";
        console.log('Singleton works, both variables contain the same instance.');
    } else {
        document.getElementById("demo").innerText="Singleton failed, variables contain different instances.";
        console.log('Singleton failed, variables contain different instances.');
    }
}



